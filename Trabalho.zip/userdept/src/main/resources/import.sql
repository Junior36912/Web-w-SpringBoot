-- import.sql

INSERT INTO tb_department(name) VALUES ('Gestão');
INSERT INTO tb_department(name) VALUES ('Informática');

INSERT INTO tb_user(department_id, name, email) VALUES (1, 'JoaoMarquin', 'mqjj@gmail.com');
INSERT INTO tb_user(department_id, name, email) VALUES (1, 'Junior', 'junin@gmail.com');
INSERT INTO tb_user(department_id, name, email) VALUES (2, 'Raiana', 'RaiNao@gmail.com');
INSERT INTO tb_user(department_id, name, email) VALUES (2, 'Barbara', 'barbs@gmail.com');
